import React from 'react'

const DemolishMine = (props) => (
    <div>
    <a className="btn btn-primary"  href="#" onClick={props.demolishMine}>Demolish Mine</a>
    </div>

)

export default DemolishMine;