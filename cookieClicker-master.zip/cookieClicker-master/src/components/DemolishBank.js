import React from 'react'

const DemolishBank = (props) => (
    <div>
    <a className="btn btn-primary"  href="#" onClick={props.demolishBank}>Demolish Bank</a>
    </div>

)

export default DemolishBank;