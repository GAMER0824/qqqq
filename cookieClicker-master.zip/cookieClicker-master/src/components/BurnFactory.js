import React from 'react'

const BurnFactory = (props) => (
    <div>
    <a className="btn btn-primary"  href="#" onClick={props.burnFactory}>Demolish Factory</a>
    </div>

)

export default BurnFactory;