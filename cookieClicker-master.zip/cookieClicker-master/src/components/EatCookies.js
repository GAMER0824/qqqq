import React from 'react'

const EatCookies = (props) => (
    <div>
    <a className="btn btn-primary"  href="#" onClick={props.eatCookies}>eat Cookies!</a>
    </div>
);

export default EatCookies;

