import React from 'react'

const FireMemaw = (props) => (
    <div>
    <a className="btn btn-primary"  href="#" onClick={props.fireMemaw}>Fire Memaw</a>
    </div>

)

export default FireMemaw;