import React from 'react'

const BurnFarm = (props) => (
<div>
<button className="btn btn-primary"  href="#" onClick = {props.burnFarm} >Burn Farm!</button>
</div>
)

export default BurnFarm;